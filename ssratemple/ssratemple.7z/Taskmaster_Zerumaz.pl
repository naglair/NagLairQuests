sub EVENT_DEATH {
	quest::signal(162273);#cursed_four
}