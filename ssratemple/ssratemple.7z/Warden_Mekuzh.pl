sub EVENT_DEATH {
	quest::signal(162277);#cursed_eight
}