sub EVENT_DEATH {
	quest::signal(162274);#cursed_five
}