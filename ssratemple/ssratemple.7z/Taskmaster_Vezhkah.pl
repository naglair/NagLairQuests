sub EVENT_DEATH {
	quest::signal(162276);#cursed_seven
}