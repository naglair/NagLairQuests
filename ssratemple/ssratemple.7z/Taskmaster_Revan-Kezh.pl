sub EVENT_DEATH {
	quest::signal(162272);#cursed_three
}