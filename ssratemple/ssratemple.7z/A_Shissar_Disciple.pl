sub EVENT_AGGRO {  
  quest::emote("spits black blood on your armor and slithers toward you.");
}

#Submitted by: Jim Mills