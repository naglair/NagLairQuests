sub EVENT_DEATH {
	quest::signalwith(162255,1,0);
}


