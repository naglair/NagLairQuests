sub EVENT_DEATH {
	quest::signal(162270);#cursed_one
}