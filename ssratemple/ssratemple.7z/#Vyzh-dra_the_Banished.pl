sub EVENT_DEATH {
	quest::signalwith(162255,2,0);
}



