sub EVENT_DEATH {
	quest::signal(162275);#cursed_six
}