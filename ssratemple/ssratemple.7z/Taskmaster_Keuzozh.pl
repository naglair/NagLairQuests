sub EVENT_DEATH {
	quest::signal(162271);#cursed_two
}