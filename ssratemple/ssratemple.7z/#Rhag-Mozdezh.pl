# second part of the arch lich rhag`zadune cycle
#

sub EVENT_DEATH {
  quest::spawn2(162177,0,0,420,-144,270.1,0); # spawn rhag`mozdezh
}

# EOF zone: ssratemple ID: 162178 NPC: #Rhag`Mozdezh

